import React from "react";
import { TextField } from "@shopify/polaris";

function InputSelect(props) {
  return (
    <>
      <div className="Polaris-Select">
        <select
          id={props.id}
          className="Polaris-Select__Input"
          aria-invalid="false"
          onChange={props.onChange}
        >
          {props.option.map((x) => {
            return (
              <option key={x.data} value={x.value}>
                {x.data}
              </option>
            );
          })}
        </select>
        <div className="Polaris-Select__Content" aria-hidden="true">
          <span className="Polaris-Select__SelectedOption">{props.value}</span>
          <span className="Polaris-Select__Icon">
            <span className="Polaris-Icon">
              <span className="Polaris-VisuallyHidden" />
              <svg
                viewBox="0 0 20 20"
                className="Polaris-Icon__Svg"
                focusable="false"
                aria-hidden="true"
              >
                <path d="M7.676 9h4.648c.563 0 .879-.603.53-1.014l-2.323-2.746a.708.708 0 0 0-1.062 0l-2.324 2.746c-.347.411-.032 1.014.531 1.014Zm4.648 2h-4.648c-.563 0-.878.603-.53 1.014l2.323 2.746c.27.32.792.32 1.062 0l2.323-2.746c.349-.411.033-1.014-.53-1.014Z" />
              </svg>
            </span>
          </span>
        </div>
        <div className="Polaris-Select__Backdrop" />
      </div>

      {props.value == "Show custom title" ? (
        <div className="mt-3">
          <TextField
            label="Custom title"
            value={props.textValue}
            onChange={props.textOnChange}
            autoComplete="off"
          />
        </div>
      ) : (
        ""
      )}
    </>
  );
}

export default InputSelect;
