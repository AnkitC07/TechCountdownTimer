const Suggestion = () =>{
    return(
        <>
        <iframe src="https://tally.so/r/waODv2" style={{width:"100%",height:'99vh'}}/>
        </>
    )
    }
export default Suggestion